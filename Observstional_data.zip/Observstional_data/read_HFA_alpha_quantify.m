clc
clear

load Eddy_SHFA  
load Eddy_LHFA
load Eddy_record
load Eddy_SSTA

Eddy_track = Eddy_record;
Eddy_track = sortrows(Eddy_track,9);

X1 = -2;
X2 = 2;
Y1 = -2;
Y2 = 2;
gap = 0.25;

X = X1:gap:X2;
Y = Y1:gap:Y2;

xx = length(X);
yy = length(Y);

r_core = [0, 1.5];   % Eddy-core region

[YY,XX] = meshgrid(Y,X);

R = sqrt(XX.^2 + YY.^2);   % Radial-distance matrix (r)

for i = 1:size(Eddy_track,1)

    i

    Edd = Eddy_track(i,:);

    SHFA_com = Eddy_SHFA{Eddy_track(i,9),1};
    LHFA_com = Eddy_LHFA{Eddy_track(i,9),1};

    HFA_com = SHFA_com + LHFA_com;
    SSTA_com = Eddy_SSTA{Eddy_track(i,9),1};

    %%% Calculate the eddy-core HFA properties ============================

    Tc_HFA = HFA_com;

    if isempty(Tc_HFA) == 0

        if isnan(Tc_HFA(9,9)) == 0

            mask_core = (R >= r_core(1) & R <= r_core(2));

            HFA_core = nanmean(HFA_com(mask_core));
            Eddy_track(i,10) = HFA_core;

            HFA_core_abs = nanmean(abs(HFA_com(mask_core)));
            Eddy_track(i,11) = HFA_core_abs;

            HFA_core_int = ...
                nansum(HFA_com(mask_core))*(Edd(6)*gap).^2;
            Eddy_track(i,13) = HFA_core_int;

            HFA_core_int_abs = ...
                nansum(abs(HFA_com(mask_core)))*(Edd(6)*gap).^2;
            Eddy_track(i,14) = HFA_core_int_abs;

        end

    end

    Tc = SSTA_com;

    if isempty(Tc) == 0

        if isnan(Tc(9,9)) == 0

            rmax = 2;
            r = hypot(XX,YY);

            % Calculate statistics only within r <= 2R and where Tc is valid
            M = (r <= rmax) & isfinite(Tc);

            if ~any(M(:))
                error( ...
                    'No valid data are available within the mask (r <= %g and valid Tc).', ...
                    rmax);
            end

            nbins = 16;

            % ----- Radial averaging to obtain T_M''(r) -----

            edges = linspace(0,rmax,nbins+1);

            [~,~,bin] = histcounts(r(M),edges);
            % Radial bin containing each grid cell

            vals = Tc(M);

            % Mean value in each radial bin
            TM_profile = accumarray( ...
                bin(:),vals(:),[nbins 1],@mean);

            % Radial-bin centres
            rc = 0.5*(edges(1:end-1) + edges(2:end));

            % Interpolate the radial mean back to each grid-cell position
            % to obtain the monopole component TM_field
            TM_field = nan(size(Tc));

            TM_field(M) = interp1( ...
                rc,TM_profile,r(M),'linear','extrap');

            % ----- Structural index alpha: Pearson correlation -----

            alpha = corr( ...
                vals(:),TM_field(M), ...
                'Rows','complete');
            % Correlation between the original and monopole component fields

            Eddy_track(i,12) = alpha;

        end

    end

end

save Eddy_track_HFA Eddy_track
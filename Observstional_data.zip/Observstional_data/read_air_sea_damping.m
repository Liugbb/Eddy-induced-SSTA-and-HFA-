clc
clear

%%%%%%%%%==================================================================
%%%%% Eddy_data:
%%%%% 1. ID; 2. track number; 3. time (from 1993/01/01)
%%%%% 4. lon; 5. lat; 6. radius (m);
%%%%% 7. polarity (1/cyclone; -1/anticyclone)
%%%%%%%%%==================================================================

load('../Eddy_record.mat')
load('../Eddy_SHFA.mat')
load('../Eddy_LHFA.mat')
load('../Eddy_SSTA.mat')

% Eddy_record(:,9) = 1:size(Eddy_record,1);

Eddy_record = sortrows(Eddy_record,2);
Eddy_record = sortrows(Eddy_record,1);

ncdisp(['/media/sust/5173010b-2665-404a-9e8d-a1754c2cc675/' ...
    'lgb/CESM/Argo_mixedlayers_monthlyclim_04142022.nc'])

mld = ncread( ...
    ['/media/sust/5173010b-2665-404a-9e8d-a1754c2cc675/' ...
    'lgb/CESM/Argo_mixedlayers_monthlyclim_04142022.nc'], ...
    'mld_da_mean');

lon_mld = ncread( ...
    ['/media/sust/5173010b-2665-404a-9e8d-a1754c2cc675/' ...
    'lgb/CESM/Argo_mixedlayers_monthlyclim_04142022.nc'], ...
    'lon');

lat_mld = ncread( ...
    ['/media/sust/5173010b-2665-404a-9e8d-a1754c2cc675/' ...
    'lgb/CESM/Argo_mixedlayers_monthlyclim_04142022.nc'], ...
    'lat');

lon_mld = [lon_mld(181:360); lon_mld(1:180)];
lon_mld(lon_mld < 0) = lon_mld(lon_mld < 0) + 360;

MLD = nan(size(mld));

for mon = 1:12

    mld_m = squeeze(mld(mon,:,:));
    mld_m = [mld_m(181:360,:); mld_m(1:180,:)];

    MLD(mon,:,:) = mld_m;

end


%%%%%%%%%%=================================================================
%%%%%%%%%% Convert cyclonic eddies into an anticyclonic-equivalent form,
%%%%%%%%%% including the SSTA and HFA fields
%%%%%%%%%%=================================================================

extent_deg = 2;              % Half-width of the patch: ±2°
dx = 0.25;                   % Patch-grid spacing

x = -extent_deg:dx:extent_deg;
y = -extent_deg:dx:extent_deg;

[YY,XX] = meshgrid(y,x);
% Note: rows correspond to longitude and columns to latitude

Ngrid = numel(x);

rho = sqrt(XX.^2 + YY.^2);

den0 = 1025;                 % Unit: kg m^-3
c0 = 4000;                   % Unit: J kg^-1 K^-1


% Precompute the eddy-core annulus mask to avoid repeated calculations
% within the loop
mask_in = (rho >= 0.1 & rho <= 1.5);
% Exclude the central grid cell and use the annulus from 0.1R to 1.5R

% mask_out = (rho >= 1.2 & rho <= 2.0);
% Enable this mask if an outer-annulus reference is required


% Threshold parameters, which may be adjusted as needed
ALPHA = 0.05;                % Significance level for the slope
MIN_N = 30;                  % Minimum sample size
STD_T_MIN = 0.05;            % SSTA standard-deviation threshold (K or °C)
LOW_W = 0.5;                 % Low-weight threshold
MAX_LOW_FRAC = 0.60;         % Maximum allowed fraction of low-weight samples
                              % A large fraction indicates many outliers
MAX_RELDIFF_OLS = 0.50;      % Maximum relative difference from the OLS slope
                              % Here, the threshold is 50%

Eddy_record(:,10:11) = nan;


for ti = 1:size(Eddy_record,1)

    ti

    % Read the current eddy record
    Edd = Eddy_record(ti,:);

    id = Edd(9);             % Index of the corresponding cell-array data

    if id < 1 || id > numel(Eddy_SHFA) || id > numel(Eddy_SSTA)

        Eddy_record(ti,10) = NaN;  % phi
        Eddy_record(ti,11) = NaN;  % Normalized coefficient

        continue

    end

    SHFA = Eddy_SHFA{id,1};
    LHFA = Eddy_LHFA{id,1};

    HFA = SHFA + LHFA;
    SSTA = Eddy_SSTA{id,1};


    % Check whether the required data exist and have consistent dimensions
    if isempty(HFA) || isempty(SSTA) || ...
            ~isequal(size(HFA),size(SSTA)) || ...
            ~isequal(size(HFA),size(rho))

        Eddy_record(ti,10) = NaN;
        Eddy_record(ti,11) = NaN;

        continue

    end


    % ---- Standardize eddy polarity so that the core SSTA is positive ----

    Tin0 = mean(SSTA(mask_in),'omitnan');

    if isfinite(Tin0) && Tin0 < 0

        SSTA = -SSTA;

        HFA = -HFA;
        % Reverse the heat-flux sign simultaneously to preserve the
        % physical sign convention that a warm anomaly loses heat

    end


    % ---- Extract and clean the samples within the core annulus ----

    t = SSTA(mask_in);
    q = HFA(mask_in);

    m = isfinite(t) & isfinite(q);

    t = t(m);
    q = q(m);


    % Apply the sample-size and variance thresholds
    if numel(t) < MIN_N

        phi = NaN;
        gotoFinalize = true;

    elseif std(t,1) < STD_T_MIN

        phi = NaN;
        gotoFinalize = true;

    else

        gotoFinalize = false;

    end

    if gotoFinalize

        % Skip this record; the MLD-related normalized value remains NaN
        continue

    end


    % ---- Winsorize the endpoints at 1% and 99% to reduce the influence
    % ---- of extreme values

    [t,q] = winsorize_(t,q,0.01,0.99);


    % ---- Robust regression: q = b0 + b1*t ----

    try

        [b,stats] = robustfit(t,q);     % Default bisquare weighting

        slope = b(2);                   % Estimated phi, W m^-2 K^-1
        p_slope = stats.p(2);

        w = stats.w(:);
        fracLow = mean(w < LOW_W);


        % Calculate the OLS slope for a consistency comparison
        p = polyfit(t,q,1);             % q ≈ p(1)*t + p(2)

        slope_ols = p(1);

        relDiff = abs(slope-slope_ols) / ...
            max(1e-12,abs(slope));


        % ---- Robustness criteria: statistical significance, fraction of
        % ---- low-weight samples, and consistency with the OLS slope

        if ~(p_slope < ALPHA) || ...
                (fracLow > MAX_LOW_FRAC) || ...
                (relDiff > MAX_RELDIFF_OLS) || ...
                ~isfinite(slope)

            phi = NaN;                  % Discard an unreliable estimate

        else

            phi = slope;                % Accept a robust estimate

        end

    catch

        phi = NaN;                      % Error handling for failed fitting

    end


    time = datevec(Edd(3));

    [ia1,ib1] = min(abs(lon_mld-Edd(4)));
    [ia2,ib2] = min(abs(lat_mld-Edd(5)));

    mld_edd = MLD(time(2),ib1,ib2);

    Eddy_record(ti,10) = phi;
    Eddy_record(ti,11) = phi/den0/c0/mld_edd;

end


for ti = 1:size(Eddy_record,1)

    ti

    Edd = Eddy_record(ti,:);
    SSTA = Eddy_SSTA{Edd(9),1};


    %%%% Calculate the structural index alpha =============================

    Tc = SSTA;

    if isempty(Tc) == 0

        if isnan(Tc(9,9)) == 0

            rmax = 2;
            r = hypot(XX,YY);


            % Calculate statistics only within r <= 2R and where Tc is valid
            M = (r <= rmax) & isfinite(Tc);

            if ~any(M(:))

                error( ...
                    'No valid data are available within the mask (r <= %g and valid Tc).', ...
                    rmax);

            end

            nbins = 16;


            % ----- Radial averaging to obtain T_M''(r) -----

            edges = linspace(0,rmax,nbins+1);

            [~,~,bin] = histcounts(r(M),edges);
            % Radial bin containing each grid cell

            vals = Tc(M);


            % Mean value within each radial bin
            TM_profile = accumarray( ...
                bin(:),vals(:),[nbins 1],@mean);


            % Radial-bin centres
            rc = 0.5*(edges(1:end-1) + edges(2:end));


            % Interpolate the radial mean back to each grid-cell position
            % to obtain the monopole component TM_field
            TM_field = nan(size(Tc));

            TM_field(M) = interp1( ...
                rc,TM_profile,r(M),'linear','extrap');


            % ----- Structural index alpha: Pearson correlation -----

            alpha = corr( ...
                vals(:),TM_field(M), ...
                'Rows','complete');
            % Correlation between the original and monopole component fields

            Eddy_record(ti,12) = alpha;

        end

    end

end


save Eddy_record_ini Eddy_record


%%%%%% Calculate the dimensionless damping rate:
%%%%%% lambda* = 2*pi*R*lambda/U
%%%%%% First calculate the corresponding eddy velocity

load('../Eddy_Uvel.mat')
load('../Eddy_Vvel.mat')
load('../Eddy_record_uv')

Eddy_record_uv = Eddy_record;

load Eddy_record_ini.mat


X1 = -2;
X2 = 2;
Y1 = -2;
Y2 = 2;
gap = 0.25;

X = X1:gap:X2;
Y = Y1:gap:Y2;

[Yn,Xn] = meshgrid(Y,X);

Dis = sqrt(Xn.^2 + Yn.^2);

idx = Dis <= 1.5 & Dis >= 0.5;
% Logical mask for the annulus between 0.5R and 1.5R


for i = 1:size(Eddy_record_uv,1)

    i

    SSU = Eddy_Uvel{Eddy_record_uv(i,9),1};
    SSV = Eddy_Vvel{Eddy_record_uv(i,9),1};

    uvel = SSU(idx);
    vvel = SSV(idx);

    % uvel = SSU(sub2ind(size(SSU),ia,ib));

    EKE = 0.5*(uvel.^2 + vvel.^2);

    Eddy_record_uv(i,13) = nanmean(EKE(:));
    % Mean eddy kinetic energy within the selected annulus

    EKE = sort(EKE(:),'descend');

    Eddy_record_uv(i,14) = ...
        nanmean(EKE(1:floor(0.25*length(EKE))+1));
    % Mean of the highest 25% of EKE values

end


zz = find(Eddy_record(:,1) == 0);
Eddy_record(zz:end,:) = [];


% === 1. Specify the seven columns used for matching ===

keyCols = 1:7;
% If the matching columns are not columns 1-7, replace them with, for
% example, [1 2 3 4 5 8 9]


% === 2. Extract the matching variables ===

key_record = Eddy_record(:,keyCols);
key_ref = Eddy_record_uv(:,keyCols);


% === 3. Perform row-by-row matching based on the seven columns ===

[isMatch,loc] = ismember(key_record,key_ref,'rows');


% === 4. Copy columns 13-14 from Eddy_record_uv to columns 13-14 of
% ===    Eddy_record for the matched records ===

Eddy_record(isMatch,13:14) = ...
    Eddy_record_uv(loc(isMatch),13:14);


Eddy_record(:,15) = ...
    2*pi*Eddy_record(:,6).*Eddy_record(:,11) ./ ...
    sqrt(2*Eddy_record(:,14));


save Eddy_record_damp Eddy_record
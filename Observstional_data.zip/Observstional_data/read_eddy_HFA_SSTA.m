clc
clear

%%%%%%%%%==================================================================
%%%%% Eddy_data:
%%%%% 1. ID; 2. track number; 3. time (from 1993/01/01)
%%%%% 4. lon; 5. lat; 6. radius (m);
%%%%% 7. polarity (1/cyclone; -1/anticyclone)
%%%%%%%%%==================================================================

load('G:\GOMEAD\Eddy_data.mat')

Eddy_data(:,3) = datenum(1993,1,1) + Eddy_data(:,3);

zz = find(Eddy_data(:,5) < 0);
Eddy_data(zz,7) = -Eddy_data(zz,7);

%%%%%%%====================================================================
%%%%% Read the OISST monthly mean file and calculate the corresponding
%%%%% monthly climatology
%%%%%%%====================================================================

ncdisp('G:\OISST\oisst.mon.mean.nc')

OISST = 'G:\OISST\oisst.mon.mean.nc';

lon_ois = ncread(OISST,'lon');
lat_ois = ncread(OISST,'lat');
time_oisst = ncread(OISST,'time');

% Time units: days since 1800-01-01 00:00:00
time_dt = datetime(1800,1,1) + days(time_oisst);

yy = year(time_dt);
mm = month(time_dt);

missing_value = ncreadatt(OISST,'sst','missing_value');

nx = length(lon_ois);
ny = length(lat_ois);

%% =========================
% 1. Monthly climatology for each period
% =========================

T_annual = nan(nx,ny,12);

for MM = 1:12

    % -------- 1995-2004 --------
    idx = find(mm == MM);

    tmp_all = nan(nx,ny,length(idx));

    for ii = 1:length(idx)

        tmp = ncread(OISST,'sst',[1 1 idx(ii)],[inf inf 1]);
        tmp = double(tmp);
        tmp(tmp < -1000) = nan;

        tmp_all(:,:,ii) = tmp;

    end

    T_annual(:,:,MM) = nanmean(tmp_all,3);

end


%%%%%%%====================================================================
%%%%%%% Read the monthly climatological mean fields
%%%%%%%====================================================================

filenameLHA = ['K:\IFREMER_OceanHeatFlux\climatology_monthly\' ...
    'surface_upward_latent_heat_flux_monthly_clim_1993_2018.nc'];

lon_cas = ncread(filenameLHA,'lon');
lat_cas = ncread(filenameLHA,'lat');

LHF_cas = ncread( ...
    filenameLHA, ...
    'surface_upward_latent_heat_flux_clim');

filenameSHA = ['K:\IFREMER_OceanHeatFlux\climatology_monthly\' ...
    'surface_upward_sensible_heat_flux_monthly_clim_1993_2018.nc'];

SHF_cas = ncread( ...
    filenameSHA, ...
    'surface_upward_sensible_heat_flux_clim');


%%%%%%%%%==================================================================
%%%% Read the OISST SST files
%%%% lon: 0 to 360; lat: -90 to 90
%%%%%%%%%==================================================================

%% ==== Parameters ====

extent_deg = 2;              % Half-width of the patch: ±2°
dx = 0.25;                   % Patch-grid spacing

x = -extent_deg:dx:extent_deg;
y = -extent_deg:dx:extent_deg;

[YY,XX] = meshgrid(y,x);     % Note: rows correspond to longitude and columns to latitude

Ngrid = numel(x);


%%%% Select the study region ==============================================
%%%%% Select the corresponding eddy-tracking records

time1 = datenum(1993,1,1);
time2 = datenum(2019,12,31);

zz = find(Eddy_data(:,3) >= time1 & Eddy_data(:,3) <= time2);
Eddy_da = Eddy_data(zz,:);

ln1 = 0;
ln2 = 360;
lt1 = -90;
lt2 = 90;

zz = find( ...
    Eddy_da(:,4) >= ln1 & Eddy_da(:,4) <= ln2 & ...
    Eddy_da(:,5) >= lt1 & Eddy_da(:,5) <= lt2);

Eddy_track = Eddy_da(zz,:);
Eddy_track = sortrows(Eddy_track,3);

Eddy_track(:,8) = 1:size(Eddy_track,1);

rank = [];
rank(1,1) = Eddy_track(1,3);
rank(1,2) = 1;

mm = 1;

for i = 1:size(Eddy_track,1)-1

    if Eddy_track(i+1,3) ~= Eddy_track(i,3)

        rank(mm,3) = i;
        rank(mm+1,1) = Eddy_track(i+1,3);
        rank(mm+1,2) = i+1;

        mm = mm+1;

    end

end

rank(end,3) = size(Eddy_track,1);

Eddy_SHA_block = cell(size(rank,1),1);
Eddy_block = cell(size(rank,1),1);

core_n = 6;
parpool('local',core_n);

parfor ra = 1:size(rank,1)

    ra

    Eddy_series = Eddy_track(rank(ra,2):rank(ra,3),:);

    Time = datevec(Eddy_series(1,3));

    year = Time(1);
    mon = Time(2);
    day = Time(3);

    Year = sprintf('%04d',year);
    Mon = sprintf('%02d',mon);
    Day = sprintf('%02d',day);

    filepath = ['K:\IFREMER_OceanHeatFlux\' Year '\'];
    name1 = 'ifremerfluxv4.1_daily-';

    filename = [name1 Year Mon Day ...
        '120000-OHF-L4-global_daily_0.25x0.25-v0.7-f01.0.nc'];

    if exist([filepath filename],'file') ~= 2
        continue;
    end

    % ncdisp([filepath filename])

    % Subtract the monthly climatology before applying spatial filtering
    lon = ncread([filepath filename],'lon');
    lat = ncread([filepath filename],'lat');

    shf_ini = ncread( ...
        [filepath filename], ...
        'surface_upward_sensible_heat_flux');

    lhf_ini = ncread( ...
        [filepath filename], ...
        'surface_upward_latent_heat_flux');

    shfa = shf_ini - SHF_cas(:,:,mon);
    lhfa = lhf_ini - LHF_cas(:,:,mon);

    shf_daily = gauss_high_2d(shfa,10,0.25);
    lhf_daily = gauss_high_2d(lhfa,10,0.25);

    %%%%%%%%==============================================================

    zz = find(lon < 0);

    if ~isempty(zz)

        shf_daily = [ ...
            shf_daily(zz(end)+1:end,:); ...
            shf_daily(1:zz(end),:)];

        lhf_daily = [ ...
            lhf_daily(zz(end)+1:end,:); ...
            lhf_daily(1:zz(end),:)];

        lon = [ ...
            lon(zz(end)+1:end); ...
            lon(1:zz(end))+360];

    end

    % Subtract the monthly climatology before applying spatial filtering
    filepath = 'G:\OISST\';
    name1 = 'oisst-avhrr-v02r01.';

    filename = [name1 Year Mon Day '.nc'];

    % ncdisp([filepath filename])

    lonS = ncread([filepath filename],'lon');
    latS = ncread([filepath filename],'lat');

    Tem_ini = ncread([filepath filename],'sst');

    Tema = Tem_ini - T_annual(:,:,mon);
    Tem = gauss_high_2d(Tema,10,0.25);


    %%%%%%%================================================================
    %%%% Read the monthly climatological SST field
    %%%%%%%================================================================

    T_ois = T_annual(:,:,mon);


    %%%%% Calculate the SST gradient ======================================

    SST = T_ois;

    [Lat,Lon] = meshgrid(lat_ois,lon_ois);

    % Calculate the grid spacing
    R = 111195;

    dlat = gradient(lat_ois);   % Meridional spacing
    dlon = gradient(lon_ois);   % Zonal spacing

    [dSST_dlat,dSST_dlon] = gradient(SST,lat_ois,lon_ois);

    % Convert to horizontal gradients in K m^-1
    SST_y = dSST_dlat/R;        % Meridional SST gradient
    SST_x = dSST_dlon/R;        % Zonal SST gradient

    % Gradient orientation angle in radians
    theta_rad = atan2(SST_x,SST_y);


    % Query points
    lonq = Eddy_series(:,4);
    latq = Eddy_series(:,5);

    Eddy_rad = interp2( ...
        lat_ois,lon_ois,theta_rad,latq,lonq,'linear');
    % Note the interpolation order: latitude first, followed by longitude

    Eddy_series(:,9) = Eddy_rad;


    %%%%% Remove the monthly mean SST =====================================

    SSTA_daily = Tem;

    % Two-dimensional interpolant for the daily SSTA field
    SSTA_F = griddedInterpolant( ...
        {lonS,latS},SSTA_daily,'linear','none');


    %%%%% Remove the monthly mean heat flux ===============================

    % Two-dimensional interpolants for the daily HFA fields
    SHFA_F = griddedInterpolant( ...
        {lon,lat},shf_daily,'linear','none');

    LHFA_F = griddedInterpolant( ...
        {lon,lat},lhf_daily,'linear','none');


    %%%%%%%%%%============================================================
    %%%%% Locate the grid around each eddy centre and normalize the
    %%%%% coordinates using the eddy radius
    %%%%%%%%%%============================================================

    local_SHA = cell(size(Eddy_series,1),1);
    local_Eddy = cell(size(Eddy_series,1),1);

    for en = 1:size(Eddy_series,1)

        EddyRow = Eddy_series(en,:);

        lonc = EddyRow(4);
        latc = EddyRow(5);
        theta = EddyRow(end);
        Rad = EddyRow(6);

        % Incorporate the constraint that the gradient direction at the
        % eddy centre corresponds to a polar angle of 90° through coordinate
        % rotation.
        %
        % In the formulation, (x_n,y_n) are defined in the transformed
        % coordinate system and are rotated back to the absolute coordinate
        % system as:
        %
        % (x_n sin(theta) - y_n cos(theta),
        %  x_n cos(theta) + y_n sin(theta))

        Xorig = ( ...
            XX.*cos(-theta) - YY.*sin(-theta))*Rad/R;
        % Return the radius-normalized longitudinal coordinates

        Yorig = ( ...
            XX.*sin(-theta) + YY.*cos(-theta))*Rad/R;
        % Return the radius-normalized latitudinal coordinates

        % Map the rotated patch coordinates back to absolute longitude and
        % latitude. For this small spatial range, longitude and latitude
        % offsets are added directly.

        lon_samp = wrapTo360(lonc + Xorig);
        % Use wrapTo360 when longitude is defined from 0° to 360°

        lat_samp = min(max(latc + Yorig,-90),90);

        SHFA_patch = arrayfun( ...
            @(a,b) SHFA_F(a,b),lon_samp,lat_samp);

        LHFA_patch = arrayfun( ...
            @(a,b) LHFA_F(a,b),lon_samp,lat_samp);

        SSTA_patch = arrayfun( ...
            @(a,b) SSTA_F(a,b),lon_samp,lat_samp);


        %%%%% =============================================================

        HFA = [];

        HFA(:,:,1) = single(SHFA_patch);
        HFA(:,:,2) = single(LHFA_patch);
        HFA(:,:,3) = single(SSTA_patch);

        local_SHA{en} = HFA;
        local_Eddy{en} = EddyRow;

    end

    Eddy_SHA_block{ra,1} = local_SHA;
    Eddy_block{ra,1} = local_Eddy;

end

delete(gcp('nocreate'));


block_len = cellfun(@numel,Eddy_SHA_block);
% Number of elements after flattening each block

max_end = max(rank(:,2));
% Maximum output position

Eddy_SHFA = cell(max_end,1);
% Preallocate memory to avoid repeated array expansion

Eddy_LHFA = cell(max_end,1);
Eddy_SSTA = cell(max_end,1);
Eddy_record = cell(max_end,1);

b = 0;

for ira = 1:size(rank,1)

    ira

    s = Eddy_SHA_block{ira};
    % s is generally a cell array, for example N × 2

    edd = Eddy_block{ira};

    if isempty(s) == 0

        % Convert all cells in the first column from double to single
        shfa = cell(size(s));
        lhfa = cell(size(s));
        eddy_d = cell(size(s));
        ssta = cell(size(s));

        for jra = 1:size(s,1)

            ss = s{jra,1};

            shfa{jra,1} = single(ss(:,:,1));
            lhfa{jra,1} = single(ss(:,:,2));
            ssta{jra,1} = single(ss(:,:,3));

            eddy_d{jra,1} = edd{jra,1};

        end

        n = numel(s);
        % Length after flattening the cell array

        Eddy_SHFA(b+1:b+size(s,1)) = shfa(:);
        % Write the entire block at once

        Eddy_LHFA(b+1:b+size(s,1)) = lhfa(:);
        % Write the entire block at once

        Eddy_SSTA(b+1:b+size(s,1)) = ssta(:);
        % Write the entire block at once

        Eddy_record(b+1:b+size(s,1)) = eddy_d(:);

        b = b + size(s,1);

    end

end


Eddy_record(b:end,:) = [];

Eddy_record = cell2mat(Eddy_record);
Eddy_record(:,9) = 1:size(Eddy_record,1);

Eddy_SHFA(b:end,:) = [];
Eddy_LHFA(b:end,:) = [];
Eddy_SSTA(b:end,:) = [];

clearvars Eddy_HFA_block

save Eddy_SHFA Eddy_SHFA
save Eddy_LHFA Eddy_LHFA
save Eddy_SSTA Eddy_SSTA
save Eddy_record Eddy_record
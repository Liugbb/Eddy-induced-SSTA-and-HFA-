function cal_eddy_ellipse(path_out,ellipse_threshold)

load([path_out,'eddy_centers'])
load([path_out,'eddy_shapes'])
   
%%% R0 is the earth averaged radius
   R0=6370;   % Km

for i=1:length(centers)

    type=centers(i).type;
    day=centers(i).day;
    daystr=datestr(day,30);
 
    num=1;
    for j=1:length(type)
        
        shapes0=shapes(i).lonlat{j};
               
        lon=shapes0(1,:);
        lat=shapes0(2,:);
        
        if length(lon)>=10
            
            for ip=1:length(lon)
                xx(ip)=cos((lat(ip)+lat(1))/2*pi/180)*R0*(lon(ip)-lon(1))/180*pi;
                yy(ip)=(lat(ip)-lat(1))*R0*pi/180;
            end
            
            ellipse_t=fit_ellipse(xx,yy);
            
            if isempty(ellipse_t.status)
                major_axis=ellipse_t.long_axis/2;
                minor_axis=ellipse_t.short_axis/2;
                eccentricity=sqrt(1-(minor_axis.^2)/(major_axis.^2));
            end
            
            if eccentricity<=ellipse_threshold
            
                eddy(i).day=day;
                eddy(i).date=str2num(daystr(1:8));
                eddy(i).type(num)=centers(i).type(j);
                eddy(i).lon(num)=centers(i).lon(j);
                eddy(i).lat(num)=centers(i).lat(j);
                eddy(i).shapes{num}=shapes0;
                eddy(i).eccentricity(num)=eccentricity;
                num=num+1;
            end
            clear xx yy    
        end
        clear lon lat shapes0
    end
end

eval(['save ',path_out,'/eddy eddy'])
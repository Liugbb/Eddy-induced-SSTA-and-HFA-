param_eddy_tracking
eddy_file=['.\Eddy_' postfix '\Tracks_all\eddy_tracks.mat'];
load(eddy_file)
data_out=['.\Eddy_' postfix '\Tracks_all\'];

for i=1:length(tracks)
    day=tracks(i).day;
    disp([num2str(i/length(tracks)*100),'%']);
    for j=1:length(day)
        lon=tracks(i).lon(j);
        lat=tracks(i).lat(j);
        shapes=tracks(i).shapes{j};
    for k=1:length(shapes)
        long(k)=m_lldist([lon,shapes(1,k)],[lat,shapes(2,k)]);
    end
        tracks(i).size(j)=nanmean(long);
        clear long
    end
end

 save([data_out,'eddy_tracks_r.mat'],'tracks','-v7.3');
   function MAIN_eddy_tracking_v2

%-------------------------
%   Ver. 1.2 May.2v2010
%   Ver. 1.1 Dec.2009
%   Authors: Francesco Nencioli , francesco.nencioli@opl.ucsb.edu,
%            Charles Dong, cdong@atmos.ucla.edu
%            Yu Liu , yliu@nuist.edu.cn    update 2015-01-24
%-------------------------

clear;clc
warning off 
param_eddy_tracking
% 
for yy=yearmin:yearmax
    disp(['start.........',num2str(yy)]);
    
    tin=find(timenum>=datenum(yy,1,1) & timenum<=datenum(yy+1,1,1)-1);
    
    if isempty(tin)
        continue
    end

    starttime=timenum(tin(1));
    endtime=timenum(tin(end));
    
% % %     uv_file_in=[data_in,num2str(yy),'/'];
    %%%% ===================== INPUT PATH (MODIFIED) =====================
    % 原来: uv_file_in=[data_in,num2str(yy),'/'];  % AVISO 每年一个目录
    % 现在: CESM 全部年份在一个目录
    uv_file_in=data_in;                                     %<<< MODIFIED
    %%%% ================================================================
    data_out=[Main_dir,'Eddy_',postfix,'/Data_',num2str(yy),'/'];
    path_in=data_out;
    path_out=[Main_dir,'Eddy_',postfix,'/Tracks_',num2str(yy),'/'];
    path_out_all=[Main_dir,'Eddy_',postfix,'/Tracks_all','/'];
    
    mkdir(data_out);
    mkdir(path_out);
    mkdir(path_out_all);

% % %     MAIN_create_surf_fields_UV_AVISO_grided(uv_file_in,data_out,starttime,endtime,...
% % %         latmin,latmax,lonmin,lonmax);
 %%%% ===================== CORE CALL (MODIFIED) =====================
    % 原来: MAIN_create_surf_fields_UV_AVISO_grided(uv_file_in,...)
    % 现在: 适配 CESM 每月一个文件的读取函数
  MAIN_create_surf_fields_UV_CESM_grided( ...
        uv_file_in, data_out, starttime, endtime, ...
        latmin, latmax, lonmin, lonmax, ...
        file_prefix, file_suffix, ...
        u_var, v_var, lon_var, lat_var, time_var);
  %%%% ================================================================    

    nc_u=[path_in,'ssu.nc'];
    nc_v=[path_in,'ssv.nc'];
    nc_dim=[path_in,'lon_lat.nc'];
    
    mod_eddy_centers(nc_u,nc_v,nc_dim,a,b,path_out)
    
    mod_eddy_shapes(nc_u,nc_v,nc_dim,rad,a,path_out)
    %     cal_eddy_ellipse(path_out,ellipse_threshold)
    
    mod_eddy_tracks_add_360(degree,r,path_out)
 
end

% % %     path_out_all=[Main_dir,'Eddy_',postfix,'/Tracks_all','/'];
full_time_tracking(postfix,yearmin,yearmax,Main_dir,path_out_all,degree,r)


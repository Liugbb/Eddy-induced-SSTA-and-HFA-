clear;clc
path_out='H:\��ά����\�Ϻ��쳣����\Database\';
mkdir(path_out)
load('H:\hycom\hycom\2010\LonLat_HYCOM.mat');
lat=lat(:,1567:1899);
lon=lon(:,386:637);
model_lon=lon;
model_lat=lat';
clear lon lat
start_time=datenum(2010,01,01);
end_time=datenum(2010,12,31);
data_in_temp='H:\hycom\hycom\0\2010\TEMP\';
mf_temp=dir([data_in_temp,'*.mat']);
data_in_u='H:\hycom\hycom\0\2010\U\';
mf_u=dir([data_in_u,'*.mat']);
data_in_v='H:\hycom\hycom\0\2010\V\';
mf_v=dir([data_in_v,'*.mat']);
load('I:\Eddy_detection\Eddy_HYCOM_0\Tracks_2010\eddy_centers.mat');
load('I:\Eddy_detection\Eddy_HYCOM_0\Tracks_2010\eddy_shapes.mat');

for i=1:length(mf_temp)
    t(i)=str2num(mf_temp(i).name(end-11:end-4));
end
for i=1:length(centers)
    time=centers(i).day;
    time=datestr(time,30);
    time=time(1:8);
    disp(time)
    model_centers(:,1)=centers(i).lon';
    model_centers(:,2)=centers(i).lat';
    model_eddyType(:,1)=centers(i).type';
    for j=1:length(shapes(i).lonlat)
        model_shapes{j,1}=shapes(i).lonlat{1,j};
    end
        time=str2num(time);
        index=find(time==t);
        ff=[data_in_temp,mf_temp(index).name];
        load(ff)
        model_temp=temp0';
        clear ff temp0
        ff=[data_in_u,mf_u(index).name];
        load(ff)
        model_u=u0';
        clear ff u0
        ff=[data_in_v,mf_v(index).name];
        load(ff)
        model_v=v0';
        clear ff v0
        temp_lon=model_lon;
        temp_lat=model_lat;
        save([path_out,'Date_',num2str(time),'.mat'],'model_centers','model_eddyType','model_shapes','model_temp','model_u','model_v','temp_lon','temp_lat','model_lon','model_lat');
        clear time index ff temp_lon temp_lat model_temp model_u model_v model_centers model_eddyType model_shapes temp u v w  f file 
end
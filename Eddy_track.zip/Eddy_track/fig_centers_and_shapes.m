%����MAIN_eddy_tracking.mat�������õ���eddy_centers.mat��eddy_shapes.mat���ݣ��ٽ��������λ�����ݣ���������ͼ��
clear;
clc;
fig_out='./Eddy_SCS\Figures_2017\';
lon=ncread('./Eddy_SCS\Data_2017\lon_lat.nc','lon');
lat=ncread('./Eddy_SCS\Data_2017\lon_lat.nc','lat');
u=ncread('./Eddy_SCS\Data_2017\ssu.nc','ssu');
v=ncread('./Eddy_SCS\Data_2017\ssv.nc','ssv');
% % ssh=ncread('./Eddy_SCS\Data_2017\ssh.nc','ssh');
mkdir(fig_out)
uu = u(:,:,1);                                                              %mask�����ļ�������½����������
nu = isnan(uu);
lon(nu)=nan;
lat(nu)=nan;

% uu=mean(u,3);                                                             %��ά�ٶ�ƽ��
% vv=mean(v,3);
% ww=sqrt(uu.^2+vv.^2);
load('./Eddy_SCS\Tracks_2017\eddy_centers.mat');
load('./Eddy_SCS\Tracks_2017\eddy_shapes.mat');
pic_num=1;
eddy_date_min=datenum(2017,01,01);   %%%%%%%%%%%
eddy_date_max=datenum(2017,12,31);   %%%%%%%%%%%
timenum=eddy_date_min:1:eddy_date_max;

for day=1:365  
    time=timenum(day);                                                         %����ʱ��ά��
    date_str=datestr(time,30);
    disp(date_str(1:8))
    h_fig=figure('visible','off');
    set(h_fig,'position',get(0,'ScreenSize'));
    m_proj('Mercator','lon',[105 125],'lat',[5 30]);
    hold on;
%     sla=sqrt(u.*u+v.*v);
%     sla=sla(:,:,day);
%     m_pcolor(lon,lat,sla);
%     cmap=cmocean('balance');
%     colormap(cmap);
%     caxis([-0.3 0.8])
%     h=colorbar;
%    set(h,'FontSize',14,'FontName','times new roman');
%     ylabel(h,'sla','fontsize',18)
    for i = 1:length(shapes(day).lonlat)
        i;
        center_lat=centers(day).lat(i);
        center_lon=centers(day).lon(i);
        shape = shapes(day).lonlat{1,i};
        if centers(day).type(i)==1
            m_plot(center_lon,center_lat,'marker','.','markeredgecolor','b');
            m_plot(shape(1,:),shape(2,:),'color','b','linewidth',1.5);
        else
            m_plot(center_lon,center_lat,'marker','x','markeredgecolor','r');
            m_plot(shape(1,:),shape(2,:),'color','r','linewidth',1.5);
        end
        
        %         m_text(center_lon,center_lat,num2str(i,'%03d'),'fontsize',10);      %���
    end
    hold on;
    
    uu=u(:,:,day);                                                          %������
    vv=v(:,:,day);
    
    step=2;
    scale_factor=1;
    m_quiver(lon(1:step:end,1:step:end),lat(1:step:end,1:step:end),uu(1:step:end,1:step:end)*scale_factor,...
        vv(1:step:end,1:step:end)*scale_factor,0,'color','k','linewidth',1);
    hold on ;  
%     m_coast('patch',[0.7 0.7 0.7],'edgecolor','k','linewidth',1);
    m_gshhs_i('patch',[.7 .7 .7]);   
    m_grid('linestyle','none','box','on','fontsize',14);
    title(date_str(1:8),'fontsize',20);
     print(h_fig,'-dpng',[fig_out,'eddy_',date_str(1:8),'.png']); %�����ļ�����
%     saveas(h_fig,[fig_out,'eddy_',date_str(1:8),'.fig']);
    %���ö�ͼ����ס��
%     F=getframe(h_fig);                                                          %f=figure
%     I=frame2im(F);
%     [I,map]=rgb2ind(I,256);
%     if pic_num==1
%         imwrite(I,map,'eddy.gif','gif','Loopcount',inf,...
%             'DelayTime',0.2);
%     else
%         imwrite(I,map,'eddy.gif','gif','WriteMode','append',...
%             'DelayTime',0.2);
%     end
%     pic_num=pic_num+1;
%     close figure 1
    
end

m_proj('stereographic','lat',-90,'long',0,'radius',45);
m_coast('patch',[.7 .7 .7],'edgecolor','k');
m_grid('xtick',12,'tickdir','in','ytick',[-75 -65 -55 -45 -35],'linest','--','fontsize',15);
hold on


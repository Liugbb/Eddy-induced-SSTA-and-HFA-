function  make_eddy_file(path_in,path_out)
out=[path_out,'Database/'];
mkdir(out)
lon=ncread([path_in,'lon_lat.nc'],'lon');
lat=ncread([path_in,'lon_lat.nc'],'lat');
% ssh=ncread([path_in,'ssh.nc'],'ssh');
u=ncread([path_in,'ssu.nc'],'ssu');
v=ncread([path_in,'ssv.nc'],'ssv');

longit=lon(:,1)';
latit=lat(1,:)';
clear lon lat
minx=min(longit);
maxx=max(longit);
miny=min(latit);
maxy=max(latit);

load([path_out,'eddy_centers']);
load([path_out,'eddy_shapes']);
for i=1:length(centers)
    Time(i)=centers(i).day;
end
save([out,'Alt_Time_lon_lat.mat'],'latit','longit','Time','-v6');
clear Time

for i=1:length(centers)
    day=centers(i).day;
    day=datestr(day,30);
    day=day(1:8);
    Alt_centers(:,1)=centers(i).lon';
    Alt_centers(:,2)=centers(i).lat';
    Alt_eddyType(:,1)=centers(i).type';
    Alt_lon=longit;
    Alt_lat=latit;
    for j=1:length(shapes(i).lonlat)
        Alt_shapes{j,1}=shapes(i).lonlat{1,j};
    end
%      Alt_sla=ssh(:,:,i);
    Alt_slau=u(:,:,i);
    Alt_slav=v(:,:,i);
    sla_lon=longit;
    sla_lat=latit;
    save([out,'Date_',num2str(day),'.mat'],'Alt_centers','Alt_eddyType','Alt_shapes','Alt_sla','Alt_ssu','Alt_ssv','sla_lon','sla_lat','Alt_lon','Alt_lat','-v6');
    clear day Alt_centers Alt_eddyType Alt_shapes Alt_sla Alt_ssu Alt_ssv sla_lon sla_lat Alt_lon Alt_lat
end
clear
clc

fig_out='G:\Eddy_bob_daily\Eddy_bob\figures_ssh2008\';
lon=ncread('G:\Eddy_bob_daily\Eddy_bob\Data_2003\lon_lat.nc','lon');
lat=ncread('G:\Eddy_bob_daily\Eddy_bob\Data_2003\lon_lat.nc','lat');
ssh=ncread('G:\Eddy_bob_daily\Eddy_bob\Data_2003\ssh.nc','ssh');

latmin=0;     
latmax=25;    
lonmin=75;    
lonmax=105;   

eddy_date_min=datenum(2003,01,01);   %%%%%%%%%%%
eddy_date_max=datenum(2003,12,31);   %%%%%%%%%%%
timenum=eddy_date_min:1:eddy_date_max;

lat=lat(1,:);
lon=lon(:,1);

disp('Plot SSH figures!')
for i=1:length(timenum)
    disp([num2str(i/length(timenum)*100),'%']);
    
    h_fig=figure('visible','off');
    set(h_fig, 'position', get(0,'ScreenSize'));
    m_proj('mercator','lat',[latmin latmax],'long',[lonmin lonmax]);
    time=timenum(i);
    ssh_fig=squeeze(ssh(:,:,i));
    date_str=datestr(time,30);
    
    hold on
    m_pcolor(lon,lat',ssh_fig');
    shading flat;
    h=colorbar('eastoutside');
    colormap(jet);
    ylabel(h,'SSH (m)','fontsize',20);
    set(h,'fontsize',20);
    
%     for aa=1:length(eddy(i).type)
% 
%         shape=eddy(i).shapes{1,aa};
%         type=eddy(i).type(aa);
%         c_lon=eddy(i).lon(aa);
%         c_lat=eddy(i).lat(aa);
%         
%         hold on
%         m_plot(shape(1,:),shape(2,:),'k-','linewidth',1);
%         if type==1
%             m_plot(c_lon,c_lat,'.','MarkerEdgeColor','r','MarkerSize',10);
%         elseif type==-1
%             m_plot(c_lon,c_lat,'x','MarkerEdgeColor','r','MarkerSize',10);
%         end
%         m_text(c_lon,c_lat,num2str(aa,'%03d'),'fontsize',8);
%         clear c_lon c_lat shape type
% 
%     end
    
    m_coast('patch',[.8 .8 .8],'edgecolor',[.1 .1 .1]);
    m_grid('linestyle','none','fontsize',15);
    title(date_str(1:8),'fontsize',15);
    print(h_fig,'-djpeg','-r150',[fig_out,'ssh0000_',date_str(1:8)]);
    pause
%     close(h_fig) 
end
clear ssh 


% ssu=ncread('G:\Eddy_bob_daily\Eddy_bob\Data_2008\ssu.nc','ssu');
% ssv=ncread('G:\Eddy_bob_daily\Eddy_bob\Data_2008\ssv.nc','ssv');
% [lon,lat]=meshgrid(lon,lat);
% disp('Plot SSUV figures!')
% for i=1:length(timenum)
%     disp([num2str(i/length(timenum)*100),'%']);
%     
%     h_fig=figure('visible','off');
%     set(h_fig, 'position', get(0,'ScreenSize'));
%     m_proj('mercator','lat',[latmin latmax],'long',[lonmin lonmax]);
%     time=timenum(i);
%     ssu_fig=squeeze(ssu(:,:,i));
%     ssv_fig=squeeze(ssv(:,:,i));
%     ssu_fig=ssu_fig';
%     ssv_fig=ssv_fig';
%     date_str=datestr(time,30);
%     
%     hold on
%     step=3;
%     m_quiver(lon(1:step:end,1:step:end),lat(1:step:end,1:step:end),...
%         ssu_fig(1:step:end,1:step:end),ssv_fig(1:step:end,1:step:end),0,'b');
%     
%     for aa=1:length(eddy(i).type)
% 
%         shape=eddy(i).shapes{1,aa};
%         type=eddy(i).type(aa);
%         c_lon=eddy(i).lon(aa);
%         c_lat=eddy(i).lat(aa);
%         
%         hold on
%         m_plot(shape(1,:),shape(2,:),'k-','linewidth',1);
%         if type==1
%             m_plot(c_lon,c_lat,'.','MarkerEdgeColor','r','MarkerSize',10);
%         elseif type==-1
%             m_plot(c_lon,c_lat,'x','MarkerEdgeColor','r','MarkerSize',10);
%         end
%         m_text(c_lon,c_lat,num2str(aa,'%03d'),'fontsize',10);
%         clear c_lon c_lat shape type
% 
%     end
%     
%     m_coast('patch',[.8 .8 .8],'edgecolor',[.1 .1 .1]);
%     m_grid('linestyle','none','fontsize',15);
%     title(date_str(1:8),'fontsize',15);
%     print(h_fig,'-djpeg','-r150',[fig_out,'ssuv_',date_str(1:8)]);
%     
%     close(h_fig)   
%     
% end
% clear ssu ssv
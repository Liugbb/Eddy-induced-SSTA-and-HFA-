%make eddy tracks file to netcdf
clear
clc
param_eddy_tracking
% % file=['/data3/GOMEAD/GOMEAD_v2024_93to23_mat/tracks/eddy_tracks_',postfix,'sort.mat'];
file=['.\Eddy_' postfix '\Tracks_all\eddy_tracks_r.mat']
load(file)
n=1;
for i=1:length(tracks)
    disp([num2str(i/length(tracks)*100),'%']);        
    m=1;
    for ii=1:length(tracks(i).day)
        for j=1:size(tracks(i).shapes{ii,1},2)
            ID(n)=i;
            eddy_type(n)=tracks(i).type(ii);
            eddy_time(n)=tracks(i).day(ii);
            eddy_size(n)=tracks(i).size(ii)*1000;
            eddy_center_lat(n)=tracks(i).lat(ii);
            eddy_center_lon(n)=tracks(i).lon(ii);
            eddy_shapes_lon(n)=tracks(i).shapes{ii,1}(1,j);
            eddy_shapes_lat(n)=tracks(i).shapes{ii,1}(2,j);            
            eddy_tracks(n)=m;
            n=n+1;
        end
        m=m+1;
    end
end
r_max=max(eddy_size);
r_min=min(eddy_size);
t_max=max(eddy_tracks);
eddy_time=eddy_time-727930;
d_min=min(eddy_time);
d_max=max(eddy_time);

lon_min=100;
lon_max=285;
lat_min=5;
lat_max=65;
if strcmp(postfix,'NP')
  lat_min = 5;
  lat_max = 65;
  lon_min = 100;                                                           %100
  lon_max = 285;
  Argo_dir ='../pacific_ocean/';
elseif strcmp(postfix,'NA')
  lat_min = 5;
  lat_max = 65;                                                             %65
  lon_min = 260;
  lon_max = 360;
  Argo_dir = '../atlantic_ocean/';
elseif strcmp(postfix,'NI')
  lat_min = 5;
  lat_max = 30;                                                             %35
  lon_min = 45;                                                             %40
  lon_max = 105;                                                            %105
  Argo_dir = '../indian_ocean/';
elseif strcmp(postfix,'SO')
  lat_min = -65;
  lat_max = -5;                                                             %35
  lon_min = 0;                                                             %40
  lon_max = 360;                                                            %105
%   Argo_dir = '';


end
clear tracks m n 
%% %
% ncid = netcdf.create([postfix,'_eddy_tracks.nc'],'CLOBBER');    %����һ��������ݵ�nc�ļ�
ncid = netcdf.create([postfix,'_eddy_tracks.nc'],'64BIT_OFFSET');% >2g
dimidx = netcdf.defDim(ncid,'obs',size(eddy_time,2));

varid1 = netcdf.defVar(ncid,'ID','NC_INT',dimidx);
varid2 = netcdf.defVar(ncid,'center_longitude','NC_FLOAT',dimidx);
varid3 = netcdf.defVar(ncid,'center_latitude','NC_FLOAT',dimidx);
varid4 = netcdf.defVar(ncid,'time','NC_SHORT',dimidx);
varid5 = netcdf.defVar(ncid,'eddy_type','NC_BYTE',dimidx);
varid6 = netcdf.defVar(ncid,'radius','NC_INT',dimidx);
varid7 = netcdf.defVar(ncid,'shapes_longitude','NC_FLOAT',dimidx);
varid8 = netcdf.defVar(ncid,'shapes_latitude','NC_FLOAT',dimidx);
varid9 = netcdf.defVar(ncid,'tracks','NC_SHORT',dimidx);

netcdf.putAtt(ncid,varid2,'axis','X');
netcdf.putAtt(ncid,varid3,'axis','Y');
netcdf.putAtt(ncid,varid7,'axis','X');
netcdf.putAtt(ncid,varid8,'axis','Y');

netcdf.putAtt(ncid,varid1,'description','Identification number of the eddy');
netcdf.putAtt(ncid,varid2,'description','Longitude of the eddy center');
netcdf.putAtt(ncid,varid3,'description','Latitude of the eddy center');
netcdf.putAtt(ncid,varid4,'description','Date of the detected eddy');
netcdf.putAtt(ncid,varid5,'description','Polarity of the eddy. In the northern hemisphere, 1 represents cyclonic, -1 represents anticyclonic, and vice versa in the southern hemisphere');
netcdf.putAtt(ncid,varid6,'description','Radius of the eddy');
netcdf.putAtt(ncid,varid7,'description','Longitude of the eddy boundary');
netcdf.putAtt(ncid,varid8,'description','Latitude of the eddy boundary');
netcdf.putAtt(ncid,varid9,'description','Eddy identification number');

netcdf.putAtt(ncid,varid1,'longname','identification number');
netcdf.putAtt(ncid,varid2,'longname','longitude of the eddy center');
netcdf.putAtt(ncid,varid3,'longname','latitude of the eddy center');
netcdf.putAtt(ncid,varid4,'longname','time');
netcdf.putAtt(ncid,varid5,'longname','rotating sense of the eddy');
netcdf.putAtt(ncid,varid6,'longname','radius of the eddy');
netcdf.putAtt(ncid,varid7,'longname','longitude of the eddy boundary');
netcdf.putAtt(ncid,varid8,'longname','latitude of the eddy boundary');
netcdf.putAtt(ncid,varid9,'longname','track number');

netcdf.putAtt(ncid,varid1,'units','ordinal');
netcdf.putAtt(ncid,varid2,'units','degrees_east');
netcdf.putAtt(ncid,varid3,'units','degrees_north');
netcdf.putAtt(ncid,varid4,'units','days since 1993-01-01');
netcdf.putAtt(ncid,varid5,'units','boolean');
netcdf.putAtt(ncid,varid6,'units','m');
netcdf.putAtt(ncid,varid7,'units','degrees_east');
netcdf.putAtt(ncid,varid8,'units','degrees_north');
netcdf.putAtt(ncid,varid9,'units','ordinal');

netcdf.putAtt(ncid,varid1,'min',num2str(ID(1)));
netcdf.putAtt(ncid,varid2,'min',num2str(lon_min));
netcdf.putAtt(ncid,varid3,'min',num2str(lat_min));
netcdf.putAtt(ncid,varid4,'min',num2str(d_min));
netcdf.putAtt(ncid,varid5,'min','-1');
netcdf.putAtt(ncid,varid6,'min',num2str(r_min));
netcdf.putAtt(ncid,varid7,'min',num2str(lon_min));
netcdf.putAtt(ncid,varid8,'min',num2str(lat_min));
netcdf.putAtt(ncid,varid9,'min','1');

netcdf.putAtt(ncid,varid1,'max',num2str(i));
netcdf.putAtt(ncid,varid2,'max',num2str(lon_max));
netcdf.putAtt(ncid,varid3,'max',num2str(lat_max));
netcdf.putAtt(ncid,varid4,'max',num2str(d_max));
netcdf.putAtt(ncid,varid5,'max','1');
netcdf.putAtt(ncid,varid6,'max',num2str(r_max));
netcdf.putAtt(ncid,varid7,'max',num2str(lon_max));
netcdf.putAtt(ncid,varid8,'max',num2str(lat_max));
netcdf.putAtt(ncid,varid9,'max',num2str(t_max));
clear r_min r_max lon_max lat_max t_max lat_min lon_min d_min d_max
netcdf.endDef(ncid);

netcdf.putVar(ncid,varid1,ID');
netcdf.putVar(ncid,varid2,eddy_center_lon');
netcdf.putVar(ncid,varid3,eddy_center_lat');
netcdf.putVar(ncid,varid4,eddy_time');
netcdf.putVar(ncid,varid5,eddy_type'); 
netcdf.putVar(ncid,varid6,eddy_size');
netcdf.putVar(ncid,varid7,eddy_shapes_lon');
netcdf.putVar(ncid,varid8,eddy_shapes_lat');
netcdf.putVar(ncid,varid9,eddy_tracks'); 
clear ID eddy_center_lon eddy_center_lat eddy_time eddy_type eddy_size eddy_shapes_lon eddy_shapes_lat eddy_tracks
netcdf.close(ncid);

% % % file='CSC_eddy_tracks.nc';
% % % ncdisp(file);
% % % ID=ncread(file,'ID');
% % % clon=ncread(file,'center_longitude');
% % % clat=ncread(file,'center_latitude');
% % % type=ncread(file,'eddy_type');
% % % radius=ncread(file,'radius');

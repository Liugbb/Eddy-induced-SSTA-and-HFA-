function day_num=date2num(day)

daystr=num2str(day);
daytime=datestr(day,30);
% disp(daytime);
yy=str2num(daytime(1:4));
mm=str2num(daytime(5:6));
dd=str2num(daytime(7:8));

day_num=datenum(yy,mm,dd);
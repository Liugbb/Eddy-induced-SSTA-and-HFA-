%����MAIN_eddy_tracking.mat�������õ���eddy_centers.mat��eddy_shapes.mat���ݣ��ٽ��������λ�����ݣ���������ͼ��
clear;
clc;
fig_out='D:\�ϼ�����̽��\Eddy_aviso\fig\';
mkdir(fig_out);
lon=ncread('D:\�ϼ�����̽��\Eddy_aviso\Data_2018\lon_lat.nc','lon');
lat=ncread('D:\�ϼ�����̽��\Eddy_aviso\Data_2018\lon_lat.nc','lat');
u=ncread('D:\�ϼ�����̽��\Eddy_aviso\Data_2018\ssu.nc','ssu');
v=ncread('D:\�ϼ�����̽��\Eddy_aviso\Data_2018\ssv.nc','ssv');
%    ssh=ncread('D:\�ϼ�����̽��\Eddy_aviso\Data_2018\ssh.nc','ssh');

uu = u(:,:,1);                                                              %mask�����ļ�������½����������
nu = isnan(uu);
lon(nu)=nan;
lat(nu)=nan;

% uu=mean(u,3);                                                             %��ά�ٶ�ƽ��
% vv=mean(v,3);
% ww=sqrt(uu.^2+vv.^2);
load('D:\�ϼ�����̽��\Eddy_aviso\Data_2018\eddy_centers.mat');
load('D:\�ϼ�����̽��\Eddy_aviso\Data_2018\eddy_shapes.mat');
pic_num=1;

for day=1:length(shapes)
    
    h_fig=figure('visible','on');
    set(h_fig,'position',get(0,'ScreenSize'));
    m_proj('stereographic','lat',-90,'long',0,'radius',50);
    %     m_coast('patch',[.7 .7 .7],'edgecolor','r');
    m_grid('xtick',12,'tickdir','in','ytick',[-75 -65 -55 -45],'linest',':','xaxisloc','top');
    eddy_date_min=datenum(2018,01,01);   %%%%%%%%%%%
    eddy_date_max=datenum(2018,01,10);   %%%%%%%%%%%
    timenum=eddy_date_min:1:eddy_date_max;
    time=timenum(day);                                                         %����ʱ��ά��
    date_str=datestr(time,30);
    
    
    lat_min=-90;
    lat_max=-60;
    lon_min=0;
    lon_max=360;
    
    hold on;
    
    for i = 1:length(shapes(day).lonlat)
        i;
        
        center_lat=centers(day).lat(i);
        center_lon=centers(day).lon(i);
        shape = shapes(day).lonlat{1,i};
        
        if centers(day).type(i)==-1
            m_plot(center_lon,center_lat,'marker','.','markeredgecolor','b','markersize',1);
            m_plot(shape(1,:),shape(2,:),'color','b','linewidth',0.8);
        else
            m_plot(center_lon,center_lat,'marker','x','markeredgecolor','r','markersize',1);
            m_plot(shape(1,:),shape(2,:),'color','r','linewidth',0.5);
        end
        
        
        % m_text(center_lon,center_lat,num2str(i,'%03d'),'fontsize',10);      %���
    end
    hold on;
    
    uu=u(:,:,day);                                                          %������
    vv=v(:,:,day);
    
    step=3;
    scale_factor=0.1;
    m_quiver(lon(1:step:end,1:step:end),lat(1:step:end,1:step:end),uu(1:step:end,1:step:end)*scale_factor,...
        vv(1:step:end,1:step:end)*scale_factor,3,'color','k','linewidth',0.35);
    hold on ;
    %legend('cyclone','anticyclone','Location','NorthEastOutside');
    m_gshhs_i('patch',[.7 .7 .7]);
    % m_annotation('textbox',[117 117.5],[36.5 37.5],'string'.str);
    % m_text(117,37,'.cyclone');
%     m_quiver(117,36.5,0.5,0.5,'k','Maxheadsize',2);
%     m_text(117,36.5,'0.5m/s');
    % m_coast('patch',[0.7 0.7 0.7],'edgecolor','k','linewidth',2);
    %     m_grid minor %('linestyle','none','box','on','fontsize',14);
    %     title(date_str(1:8));
    print(h_fig,'-dpng',[fig_out,'eddy_',date_str(1:8),'.png']); %�����ļ�����
    saveas(h_fig,[fig_out,'eddy_',date_str(1:8),'.fig']);
    %���ö�ͼ����ס��
    F=getframe(h_fig);                                                          %f=figure
    I=frame2im(F);
    [I,map]=rgb2ind(I,256);
    if pic_num==1
        imwrite(I,map,'eddies.gif','gif','Loopcount',inf,...
            'DelayTime',0.2);
    else
        imwrite(I,map,'eddies.gif','gif','WriteMode','append',...
            'DelayTime',0.2);
    end
    pic_num=pic_num+1;
    close figure 1
    
end





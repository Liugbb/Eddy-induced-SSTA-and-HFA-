function MAIN_create_surf_fields_UV_CESM_grided(uv_file_in,data_out,...
       starttime,endtime,latmin,latmax,lonmin,lonmax,...
       file_prefix,file_suffix,u_var,v_var,lon_var,lat_var,time_var)

% 说明（按你的最新条件）：
% 1) 输入：每月一个文件，变量维度 lon lat time
% 2) 文件内的 time 变量 = MATLAB 的 datenum（你自己算出来直接写进 nc 的）
%    因此不需要解析 units，也不需要 “days since ...”
% 3) 输出保持和原 AVISO 版本一致：lon_lat.nc / ssu.nc / ssv.nc 结构不变
% 4) 代码风格尽量沿用你原来的写法：先构造 ftime，再在日循环里 index_t=find(t==ftime)

out_name={'ssu','ssv'};
time=starttime:1:endtime;

%%% =========================
%%%% [MOD-1] 找到所有"月文件"（原来是 daily *.nc）
%%%% =========================
file=dir(fullfile(uv_file_in,[file_prefix,'*',file_suffix]));   % <<< MOD-1
if isempty(file)
    error('No monthly files found in %s with pattern %s*%s',uv_file_in,file_prefix,file_suffix);
end

%%% =========================
%%% [MOD-2] 构造 ftime（逐日时间轴），但来源改为"月文件内的 time 向量”
%%% time_var 里已经是 datenum，所以直接用即可
%%% ftime(j) 对应 file_index(j), time_index(j)
%%% =========================
ftime      = [];
file_index = [];
time_index = [];

for k=1:length(file)
    fpath = fullfile(uv_file_in,file(k).name);

    tvec = double(ncread(fpath,time_var));     % <<< MOD-2: 直接读取 datenum
    tvec = round(tvec(:));                    % <<< MOD-2: 按天匹配，防止小数误差

    ftime      = [ftime; tvec];
    file_index = [file_index; repmat(k,numel(tvec),1)];
    time_index = [time_index; (1:numel(tvec))'];
end

% 去重：如果某些天在两个文件里都出现，只保留第一次出现
[ftime, ia] = unique(ftime,'stable');
file_index  = file_index(ia);
time_index  = time_index(ia);

%%%% =========================
%%%% 网格与 mask 部分：尽量保持原写法
%%%% =========================
ngrid=fullfile(uv_file_in,file(1).name);
lat=ncread(ngrid,lat_var);
lon=ncread(ngrid,lon_var);
lon(lon<0)=lon(lon<0)+360;

Nlat=find(lat<=latmax&lat>=latmin);
ymin=min(Nlat);ymax=max(Nlat);
Nlon=find(lon<=lonmax&lon>=lonmin);
xmin=min(Nlon);xmax=max(Nlon);

lat=lat(Nlat);
lon=lon(Nlon);
[Lon,Lat]=meshgrid(lon,lat);

nx = xmax-xmin+1;
ny = ymax-ymin+1;

% [MOD-3] u/v 取第1个 time 切片用于 mask（lon lat time）
u=ncread(ngrid,u_var,[xmin,ymin,1],[nx,ny,1]);          % <<< MOD-3
u=squeeze(u)';

v=ncread(ngrid,v_var,[xmin,ymin,1],[nx,ny,1]);          % <<< MOD-3
v=squeeze(v)';

vel=sqrt(u.^2+v.^2);

%%%%%%%%%%%%%%%%%%%%%%%%%%  use etopo5 to create mask %%%%%%%%%%%%%%%%%%%%%%
nc = netcdf('etopo5.nc', 'nowrite');
tlon=nc{'topo_lon'}(:);
tlon(tlon<0)=tlon(tlon<0)+360;
tlat=nc{'topo_lat'}(:);
topo=nc{'topo'}(:);

Ntlat=find(tlat<=latmax&tlat>=latmin);
Ntlon=find(tlon<=lonmax&tlon>=lonmin);
tlat=tlat(Ntlat);
tlon=tlon(Ntlon);
topo=topo(Ntlat,Ntlon);

[TX TY]=meshgrid(tlon,tlat);
topo=interp2(TX,TY,topo,Lon,Lat);
topo(topo>=0)=0;
topo(topo<0)=1;
mask_rho=topo;
mask_rho(vel>300)=0;

% interpolate lon lat and mask to a higher res grid
[X Y]=meshgrid(1:size(Lon,2),1:size(Lat,1));
[Xx Yy]=meshgrid(1:.67:size(Lon,2),1:.67:size(Lat,1));
Lon=interp2(X,Y,Lon,Xx,Yy);
Lat=interp2(X,Y,Lat,Xx,Yy);
mask_rho=interp2(X,Y,mask_rho,Xx,Yy);
mask_rho(mask_rho<1)=0;

% create netcdf file with lat lon
nw = netcdf([data_out,'lon_lat.nc'],'clobber');
nw('x') = size(Lon,2);
nw('y') = size(Lat,1);

nw{'lon'} = ncdouble('y', 'x');
nw{'lon'}.long_name = ncchar('longitude of RHO-points');
nw{'lon'}.long_name = 'longitude of RHO-points';
nw{'lon'}.units = ncchar('degree_east');
nw{'lon'}.units = 'degree_east';

nw{'lat'} = ncdouble('y', 'x');
nw{'lat'}.long_name = ncchar('latitude of RHO-points');
nw{'lat'}.long_name = 'latitude of RHO-points';
nw{'lat'}.units = ncchar('degree_north');
nw{'lat'}.units = 'degree_north';

nw{'mask'} = ncdouble('y', 'x');
nw{'mask'}.long_name = ncchar('mask on RHO-points');
nw{'mask'}.long_name = 'mask on RHO-points';
nw{'mask'}.option_0 = ncchar('land');
nw{'mask'}.option_0 = 'land';
nw{'mask'}.option_1 = ncchar('water');
nw{'mask'}.option_1 = 'water';

close(nw)

%%% create netcdf file for surface fields
for i=1:size(out_name,2)
    nw = netcdf([data_out,char(out_name(i)),'.nc'], 'clobber');
    nw('x') = size(Lon,2);
    nw('y') = size(Lat,1);
    nw('time')= size(time,2);

    nw{'day'} = ncdouble('time');
    nw{'day'}.long_name = ncchar('day');
    nw{'day'}.long_name = 'day';
    nw{'day'}.units = ncchar('days');
    nw{'day'}.units = 'days';

    nw{char(out_name(i))} = ncdouble('time','y', 'x');
    close(nw)
end

% fill lon lat mask
nw=netcdf([data_out,'lon_lat.nc'],'write');
nw{'lat'}(:)=Lat;
nw{'lon'}(:)=Lon;
nw{'mask'}(:)=mask_rho;
close(nw)

clear lat lon pm pn mask_rho

%%%% =========================
%%%% 填充 ssu / ssv：保持你原来的写法，只改输入定位与读取切片
%%%% =========================
disp('Create input files!')
nw1=netcdf([data_out,'ssu.nc'], 'write');
nw2=netcdf([data_out,'ssv.nc'], 'write');

for i=1:length(time)
    disp([num2str(i/length(time)*100),'%'])
    t = time(i);

    index_t = find(t==ftime,1,'first');

    if isempty(index_t)
        disp(['No data found for day ', datestr(t,'yyyy-mm-dd'), ', skip and fill NaN'])

        ssu = nan(size(Lon));
        ssv = nan(size(Lon));

        nw1{'day'}(i) = time(i);
        nw1{'ssu'}(i,:,:) = ssu;

        nw2{'day'}(i) = time(i);
        nw2{'ssv'}(i,:,:) = ssv;

        clear ssu ssv
        continue
    end

    filename = fullfile(uv_file_in, file(file_index(index_t)).name);
    it = time_index(index_t);

    ssu = ncread(filename,u_var,[xmin,ymin,it],[nx,ny,1]);
    ssu = squeeze(ssu)';
    ssu(ssu<=-2e+9) = nan;
    ssu = interp2(X,Y,ssu,Xx,Yy);

    nw1{'day'}(i) = time(i);
    nw1{'ssu'}(i,:,:) = ssu;
    clear ssu

    ssv = ncread(filename,v_var,[xmin,ymin,it],[nx,ny,1]);
    ssv = squeeze(ssv)';
    ssv(ssv<=-2e+9) = nan;
    ssv = interp2(X,Y,ssv,Xx,Yy);

    nw2{'day'}(i) = time(i);
    nw2{'ssv'}(i,:,:) = ssv;
    clear ssv
end
%%%%%%%%%%%%%%%%%%%% the region %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%                     ѡ��ģʽִ�е�����
% postfix = 'NA';
% postfix = 'NI';
% postfix = 'NP';
% postfix = 'SA';
% postfix = 'SI';
% postfix = 'SP';
  postfix = 'KE';

% -----    ָ��Argo���ݵ�ʱ�䷶Χ   ----------------------------------------
%
% Argo_date_min = datenum(1995,09,07);
% Argo_date_max = datenum(2011,10,07);
%
%------  ָ������̽���ʱ�䷶Χ   -------------------------------------------

yearmin         = 1993;                    % ʱ���2001�꿪ʼ           
yearmax         = 1993;                    % ʱ����2002�����    
data_resolution = 7;                       % ���ݵ�ʱ��ֱ��ʣ�7��һ��
eddy_date_min   = datenum(1993,01,06);     % ����̽�⿪ʼ�ľ���ʱ��
eddy_date_max   = datenum(1993,05,26);     % ����̽�������ʱ��
timenum         = eddy_date_min:data_resolution:eddy_date_max;  % ̽��ִ��ʱ��

% timelimit     = 4;                       % �޶����������ڶ೤ʱ�������

%------   ѡ������  --------------------------------------------------------

if strcmp(postfix,'NP')
  latmin = 5;
  latmax = 65;
  lonmin = 100;                                                           %100
  lonmax = 285;
  Argo_dir ='../pacific_ocean/';
elseif strcmp(postfix,'NA')
  latmin = 5;
  latmax = 65;                                                             %65
  lonmin = 260;
  lonmax = 360;
  Argo_dir = '../atlantic_ocean/';
elseif strcmp(postfix,'NI')
  latmin = 5;
  latmax = 30;                                                             %35
  lonmin = 45;                                                             %40
  lonmax = 105;                                                            %105
  Argo_dir = '../indian_ocean/';
elseif strcmp(postfix,'MS')
  latmin = 30;
  latmax = 47;
  lonmin = 0;
  lonmax = 45;
  Argo_dir = '../mediterranean_sea/';
elseif strcmp(postfix,'CS')
  latmin = 40;
  latmax = 45;
  lonmin = 45;
  lonmax = 60;
  Argo_dir = '../Caspian Sea/';
elseif strcmp(postfix,'SA')
  latmin = -60;
  latmax = -5;
  lonmin = -75;
  lonmax = 20;
  Argo_dir = '../atlantic_ocean/';
elseif strcmp(postfix,'SI')
  latmin = -60;
  latmax = -5;
  lonmin = 20;
  lonmax = 145;
  Argo_dir = '../indian_ocean/';
elseif strcmp(postfix,'KE')
  latmin = 28;
  latmax = 40;
  lonmin = 140;
  lonmax = 180;
  Argo_dir = '../indian_ocean/';
end
